

class Breakout extends Game {
  constructor(canvas){
    super(canvas);
    this.player = null;
    this.ball = null;
    this.brickWidth = 58;
    this.needLaunch = true;
    this.awake();
  }

  awake(){
    super.awake();
    this.player = this.instantiate(Paddle, false);
    this.ball = this.instantiate(Ball, false, [this.player.transform.x, this.player.transform.y]);
    this.buildBricks();
    this.ballSpeed = 500;
    window.GAME = this; // for debugging
  }

  buildBricks(){
    for(let i = 0; i < 8; i++){
      for(let j = 0; j < 14; j++){
        this.instantiate(
          Brick,
          true,
          [
            this.getColor(i),
            110 + (j*60), // xpos
            200 + (i*34) // ypos
          ]
        )
      }
    }
  }

  getColor(index){
    if(index < 2) return 'green';
    if(index < 4) return 'blue';
    if(index < 6) return 'orangered';
    return 'yellow';
  }

}

function startGame(){
  const canvas = document.getElementById('main-canvas');
  return new Breakout(canvas);
};

(function(){
  let game = startGame();
})();
