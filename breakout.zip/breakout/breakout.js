class Paddle extends multiple([Collider]) {
  constructor(game){
    super(game);
    this.name = 'paddle';
    this.transform = new Transform(
      (game.canvas.width / 2),
      (game.canvas.height) - (game.canvas.height / 6)
    );
    this.width = 100;
    this.height = 10;
    this.setColliderType(
      'box',
      {
        width: this.width, height: this.height,
        useWalls: true
      }
    );
    this.speed = 600;
  }

  onCollision(other, dir){
    if(other.type == 'wall'){
      if(dir == 'right') this.transform.x = this.game.width - (this.width / 2) - 1;
      if(dir == 'left') this.transform.x = (this.width / 2) + 1;
    }
  }

  update(deltaTime){
    this.transform.translate(
      deltaTime / 1000 * this.speed * (this.game.input.getAxis('x')),
      0
    );
  }

  render(){
    this.game.graphics.drawRect(
      this.transform,
      this.width,
      this.height,
      {
        fillStyle: "#4CAF50",
        strokeStyle: null,
      }
    );
  }
}

class Brick extends multiple([Collider]){
  constructor(color, x, y, game){
    super(game);
    this.name = 'brick';
    this.setColliderType(
      'box',
      {
        width: this.game.brickWidth, height: 30
      }
    );
    this.color = color;
    this.transform.x = x;
    this.transform.y = y;
  }

  render(){
    this.game.graphics.drawRect(
      this.transform,
      this.game.brickWidth,
      30,
      {
        fillStyle: this.color,
        strokeStyle: null,
      }
    );
  }
}

class Ball extends multiple([Collider]){
  constructor(x,y,game){
    super(game);
    this.name = 'ball';
    const startAngle = 45//80 + this.game.math.random(20);
    this.radius = 10;
    this.vector = new Vector(
      this.game.math.cos(startAngle),
      this.game.math.sin(startAngle)
    );
    this.setColliderType(
      'box',
      {
        width: this.radius * this.game.math.sin(45) * 2,
        height: this.radius * this.game.math.sin(45) * 2,
        useWalls: true,
      }
    );
    this.transform.x = x;
    this.transform.y = y;
  }
  onCollision(other, dir){
    if(other.name == 'paddle'){
      const diff = this.transform.x - other.transform.x;
      this.vector.x = this.game.math.cos(90 - (1.5*diff));
      this.vector.y = this.game.math.sin(90 - (1.5*diff));
      return;
    }
    if(dir == 'left') this.vector.x = Math.abs(this.vector.x);
    if(dir == 'right') this.vector.x = -1*Math.abs(this.vector.x);
    if(dir == 'top') this.vector.y = -1*Math.abs(this.vector.y);
    if(dir == 'bottom') this.vector.y = Math.abs(this.vector.y);
    if(other.name == 'brick') this.game.destroy(other);
  }

  update(deltaTime){
    if(this.game.input.getAxis('fire') == 1 && this.game.needLaunch){
      this.game.needLaunch = false;
    }
    if(this.game.needLaunch){
      this.transform.x = this.game.player.transform.x;
      this.transform.y = this.game.player.transform.y - 20;
    } else {
      this.transform.translate(
        this.vector.x * this.game.ballSpeed * deltaTime / 1000,
        -1 * (this.vector.y * this.game.ballSpeed * deltaTime / 1000)
      );
    }
  }

  render(){
    this.game.graphics.drawCircle(
      this.transform,
      this.radius,
      {
        fillStyle: 'white',
        shouldStroke: false,
      }
    )
  }
}
