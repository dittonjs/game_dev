// Transform
// Handles motion and position


class Transform {
  constructor(x, y, rotation){
    this.x = x;
    this.y = y;
    this.rotation = rotation;
  }

  translate(x, y){
    this.x += x;
    this.y += y;
  }
}

class Vector {
  constructor(x, y){
    // normal vector less than 1 corresponds to sin and cos functions.
    this.x = x;
    this.y = y;
  }

}

function multiple(parents){
  let GameObjectWithMixin = class extends GameObject{
    constructor(...args){
      super(...args);
    }
  };
  _.each(parents, (className)=>{
    _.each(Object.getOwnPropertyNames(className.prototype), (name)=>{
      if(name != "constructor"){
        GameObjectWithMixin.prototype[name] = className.prototype[name];
      }
    });
  });
  return GameObjectWithMixin;
}

// MIXINS
class Collider {

  _onCollision(other, dir){
    this.onCollision && this.onCollision(other, dir);
  }

  _checkCollision(other){
    if(other === this) {
      this._collider_opts.useWalls && this._checkWallCollision();
      return;
    }
    const {isBetween} = this.game.math;
    const {width:myWidth, height:myHeight} = this._collider_opts;
    const {width:otherWidth, height:otherHeight} = other._collider_opts;
    const {x:myX, y:myY} = this.transform;
    const {x:otherX, y:otherY} = other.transform;
    if( isBetween(otherX - (otherWidth/2), otherX+(otherWidth/2), myX + (myWidth/2)) &&
        (
          isBetween(otherY-(otherHeight/2), otherY+(otherHeight/2), myY - (myHeight/2)) ||
          isBetween(otherY-(otherHeight/2), otherY+(otherHeight/2), myY + (myHeight/2))
        ) && myX < otherX-(otherWidth/2)
      ){
      this._onCollision(other, 'right');
    }
    else if( isBetween(otherX - (otherWidth/2), otherX+(otherWidth/2), myX - (myWidth/2)) &&
        (
          isBetween(otherY-(otherHeight/2), otherY+(otherHeight/2), myY - (myHeight/2)) ||
          isBetween(otherY-(otherHeight/2), otherY+(otherHeight/2), myY + (myHeight/2))
        ) && myX > otherX+(otherWidth/2)
      ){
      this._onCollision(other, 'left');
    }
    // on top

    else if( isBetween(otherY - (otherHeight/2), otherY+(otherHeight/2), myY -(myHeight/2)) &&
        (
          isBetween(otherX-(otherWidth/2), otherX+(otherWidth/2), myX - (myWidth/2)) ||
          isBetween(otherX-(otherWidth/2), otherX+(otherWidth/2), myX + (myWidth/2))
        ) && myY > otherY+(otherHeight/2)
      ){
      this._onCollision(other, 'top');
    }

    // on bottom
    else if( isBetween(otherY - (otherHeight/2), otherY+(otherHeight/2), myY + (myHeight/2)) &&
        (
          isBetween(otherX-(otherWidth/2), otherX+(otherWidth/2), myX - (myWidth/2)) ||
          isBetween(otherX-(otherWidth/2), otherX+(otherWidth/2), myX + (myWidth/2))
        ) && myY < otherY-(otherHeight/2)
      ){
      this._onCollision(other, 'bottom');
    }

  }
  _checkWallCollision(){
    if(this.transform.x - (this._collider_opts.width/2) < 0) this._onCollision({type: 'wall'}, 'left');
    if(this.transform.x + (this._collider_opts.width/2) > this.game.width) this._onCollision({type: 'wall'}, 'right');
    if(this.transform.y - (this._collider_opts.height/2) < 0 ) this._onCollision({type: 'wall'}, 'top');
    if(this.transform.y + (this._collider_opts.height/2) > this.game.height) this._onCollision({type: 'wall'}, 'bottom');
  }
  setColliderType(type, opts = {}){
    this._collider_type = type; // one of 'box' or 'circle'
    this._collider_opts = opts;
  }
}

// Math
// basically just extentions of the math library
class JMath {
  sin(degrees){
    return Math.sin(this.degToRad(degrees));
  }

  cos(degrees){
    return Math.cos(this.degToRad(degrees));
  }

  degToRad(deg){
    return deg * (Math.PI/180);
  }

  radToDeg(rad){
    return rad * (180/Math.PI);
  }

  asin(val){
    return radToDeg(Math.asin(val));
  }

  acos(val){
    return radToDeg(Math.acos(val));
  }

  isBetween(lower, upper, target){
    return target > lower && target < upper;
  }

  random(top){
    return Math.floor((Math.random() * top));
  }
}

// GameInput
// handles axis and probably other stuff in the future

class GameInput {
  constructor(){
    this.axis = {
      x: 0,
      y: 0,
      fire: 0,
    }
    this.axisListener = this.axisListener.bind(this);
    window.addEventListener("keydown", this.axisListener);
    window.addEventListener("keyup", this.axisListener);
  }

  setAxis(axis, value){
    this.axis[axis] = value;
  }

  getAxis(axis){
    return this.axis[axis];
  }

  axisListener(e){
    e.preventDefault();
    switch(e.keyCode){
      case 38:
      case 87:
      case 73: {
        let val;
        if(e.type == "keydown"){
          val = -1;
        }
        if(e.type == "keyup"){
          if(this.getAxis('y') == -1){
            val = 0;
          } else {
            val = this.getAxis('y');
          }
        }
        this.setAxis('y', val);
        break;
      }
      case 40:
      case 83:
      case 75:{
        let val;
        if(e.type == "keydown"){
          val = 1;
        }
        if(e.type == "keyup"){
          if(this.getAxis('y') == 1){
            val = 0;
          } else {
            val = this.getAxis('y');
          }
        }
        this.setAxis('y', val);
        break;
      }
      case 37:
      case 65:
      case 74:{
        let val;
        if(e.type == "keydown"){
          val = -1;
        }
        if(e.type == "keyup"){
          if(this.getAxis('x') == -1){
            val = 0;
          } else {
            val = this.getAxis('x');
          }
        }
        this.setAxis('x', val);
        break;
      }
      case 39:
      case 68:
      case 76: {
        let val;
        if(e.type == "keydown"){
          val = 1;
        }
        if(e.type == "keyup"){
          if(this.getAxis('x') == 1){
            val = 0;
          } else {
            val = this.getAxis('x');
          }
        }
        this.setAxis('x', val);
        break;

      }
      case 32: {
        this.setAxis('fire', e.type == 'keydown' ? 1 : 0);
      }
      default:
        break;
    }
  }
}

// GameObject
// The base class for all game objects in the game

class GameObject {

  constructor(game, parent){
    this.transform = new Transform(0,0);
    this.game = game;
    this.parent = parent;
  }

  awake(){}

  update(elapsedTime){}

  render(context){};
}

// Game
// The base class for the game.

class Game {
  constructor(canvas){
    this.canvas = canvas;
    this.width = canvas.width;
    this.height = canvas.height;
    this.context = canvas.getContext('2d');
    this.graphics = new JdCanvasApi(this.context);
    this.pendingInput = [];
    this.readyInput = [];
    this.gameObjects = [];
    this.staticGameObjects = [];
    this.elapsedTime = 0;
    this.math = new JMath();
    this.input = new GameInput();
    this.shouldContinue = true;
    this.gameLoop = this.gameLoop.bind(this);
    this.resetTimestamp = true;
    this._toBeDestroyed = [];
  }

  awake(){
    this.start();
  }

  start(){
    requestAnimationFrame(this.gameLoop);
  }

  stop(){
    this.shouldContinue = false;
  }

  gameLoop(timestamp) {
    if(this.resetTimestamp){
      this.elapsedTime = timestamp;
      this.resetTimestamp = false;
      requestAnimationFrame(this.gameLoop);
      return;
    }
    const timeSinceLastUpdate = timestamp - this.elapsedTime;
    this.elapsedTime = timestamp;
    this.getInput();
    this.update(timeSinceLastUpdate);
    this.render();
    this.clearInput();
    this.shouldContinue && requestAnimationFrame(this.gameLoop);
  }

  getInput(){
    this.readyInput = [...this.pendingInput];
    this.pendingInput = [];
  }

  checkCollisions(){
    _.each(this.gameObjects, (obj)=>{
      _.each(this.gameObjects, (other)=>{
        obj._checkCollision && obj._checkCollision(other);
      });
      _.each(this.staticGameObjects, (other)=>{
        obj._checkCollision && obj._checkCollision(other);
      });
    });
  }

  update(timeSinceLastUpdate){
    _.each(this.gameObjects, gameObject => gameObject.update(timeSinceLastUpdate));
    this.checkCollisions();
    this._destroyQueue();
  }

  render(){
    this.clearForRerender();
    _.each(this.staticGameObjects, gameObject => gameObject.render(this.context));
    _.each(this.gameObjects, gameObject => gameObject.render(this.context));
  }

  clearForRerender(){
    this.context.save();
    this.context.setTransform(1, 0, 0, 1, 0, 0);
    this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.context.restore();
  }

  clearInput(){
    this.readyInput = [];
  }

  instantiate(gameObject, isStatic, constructArgs = [], parent){
    const obj = new gameObject(...constructArgs, this, parent);
    if(isStatic){
      this.staticGameObjects.push(obj);
    } else {
      this.gameObjects.push(obj);
    }
    return obj;
  }

  destroy(obj){
    this._queueDestroy(obj)
  }

  _queueDestroy(obj){
    this._toBeDestroyed.push(obj);
  };

  _destroyQueue(){
    _.each(this._toBeDestroyed, (obj) => {
      _.remove(this.gameObjects, obj);
      _.remove(this.staticGameObjects, obj);
    })
    this._toBeDestroyed = [];
  }
}
