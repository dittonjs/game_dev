class Transform {
  constructor(x, y, rotation){
    this.x = x;
    this.y = y;
    this.rotation = rotation;
  }
}
