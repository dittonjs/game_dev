To run:
open index.html in the browser

YOU MUST BE CONNECTED TO THE INTERNET because my game loop has a dependency on lodash.
